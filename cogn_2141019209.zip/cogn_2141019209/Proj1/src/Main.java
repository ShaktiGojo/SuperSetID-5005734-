public class Main {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        Product product1 = new Product("1", "Product1", 10, 99.99);
        Product product2 = new Product("2", "Product2", 20, 199.99);
        inventory.addProduct(product1);
        inventory.addProduct(product2);
        System.out.println(inventory);
        Product updatedProduct1 = new Product("1", "UpdatedProduct1", 15, 89.99);
        inventory.updateProduct("1", updatedProduct1);
        System.out.println("After updating Product1:");
        System.out.println(inventory);
        inventory.deleteProduct("2");
        System.out.println("After deleting Product2:");
        System.out.println(inventory);
        Product retrievedProduct = inventory.getProduct("1");
        System.out.println("Retrieved Product:");
        System.out.println(retrievedProduct);
    }
}
