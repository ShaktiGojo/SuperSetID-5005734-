public class Main {
    public static void main(String[] args) {
        EmployeeManagement management = new EmployeeManagement(10);
        management.addEmployee(new Employee(1, "Alice", "Manager", 75000));
        management.addEmployee(new Employee(2, "Bob", "Developer", 60000));
        management.addEmployee(new Employee(3, "Charlie", "Analyst", 50000));
        System.out.println("All Employees:");
        management.traverseEmployees();
        System.out.println("\nSearch for Employee with ID 2:");
        Employee emp = management.searchEmployee(2);
        if (emp != null) {
            System.out.println(emp);
        } else {
            System.out.println("Employee not found.");
        }

        // Deleting an employee
        System.out.println("\nDeleting Employee with ID 2:");
        management.deleteEmployee(2);
        management.traverseEmployees();
    }
}
