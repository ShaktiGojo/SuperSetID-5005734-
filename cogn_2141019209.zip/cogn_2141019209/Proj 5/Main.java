public class Main {
    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();
        taskList.addTask(new Task(1, "Design Database", "Pending"));
        taskList.addTask(new Task(2, "Develop API", "In Progress"));
        taskList.addTask(new Task(3, "Test Application", "Completed"));
        System.out.println("All Tasks:");
        taskList.traverseTasks();
        System.out.println("\nSearch for Task with ID 2:");
        Task task = taskList.searchTask(2);
        if (task != null) {
            System.out.println(task);
        } else {
            System.out.println("Task not found.");
        }
        System.out.println("\nDeleting Task with ID 2:");
        taskList.deleteTask(2);
        taskList.traverseTasks();
    }
}
