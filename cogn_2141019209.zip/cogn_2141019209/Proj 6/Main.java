import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        Book[] books = {
            new Book(1, "The Catcher in the Rye", "J.D. Salinger"),
            new Book(2, "To Kill a Mockingbird", "Harper Lee"),
            new Book(3, "1984", "George Orwell"),
            new Book(4, "Pride and Prejudice", "Jane Austen"),
            new Book(5, "The Great Gatsby", "F. Scott Fitzgerald")
        };

        Library library = new Library(books);
        System.out.println("Linear Search:");
        Book foundBook = library.linearSearchByTitle("1984");
        if (foundBook != null) {
            System.out.println(foundBook);
        } else {
            System.out.println("Book not found.");
        }
        System.out.println("\nBinary Search:");
        foundBook = library.binarySearchByTitle("1984");
        if (foundBook != null) {
            System.out.println(foundBook);
        } else {
            System.out.println("Book not found.");
        }
    }
}

class Book {
    int bookId;
    String title;
    String author;

    public Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    @Override
    public String toString() {
        return "Book{" +
                "bookId=" + bookId +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                '}';
    }
}

class Library {
    private Book[] books;

    public Library(Book[] books) {
        this.books = books;
    }

    public Book linearSearchByTitle(String title) {
        for (Book book : books) {
            if (book.title.equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public Book binarySearchByTitle(String title) {
        Arrays.sort(books, Comparator.comparing(book -> book.title));
        return binarySearchByTitle(title, 0, books.length - 1);
    }

    private Book binarySearchByTitle(String title, int left, int right) {
        if (left > right) {
            return null;
        }
        int mid = left + (right - left) / 2;
        int comparison = books[mid].title.compareToIgnoreCase(title);
        if (comparison == 0) {
            return books[mid];
        }
        if (comparison > 0) {
            return binarySearchByTitle(title, left, mid - 1);
        } else {
            return binarySearchByTitle(title, mid + 1, right);
        }
    }
}
