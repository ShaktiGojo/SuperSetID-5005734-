public class BuilderPatternExample {
    public static void main(String[] args) {
        Computer basicComputer = new Computer.ComputerBuilder("Intel i5", "8GB", "256GB SSD")
                .build();
        Computer highEndComputer = new Computer.ComputerBuilder("Intel i9", "32GB", "1TB SSD")
                .setGraphicsCardEnabled(true)
                .setBluetoothEnabled(true)
                .build();
        Computer midRangeComputer = new Computer.ComputerBuilder("Intel i7", "16GB", "512GB SSD")
                .setGraphicsCardEnabled(true)
                .build();
        System.out.println("Basic Computer: " + basicComputer);
        System.out.println("High-End Computer: " + highEndComputer);
        System.out.println("Mid-Range Computer: " + midRangeComputer);
    }
}
