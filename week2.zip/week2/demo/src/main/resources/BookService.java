package com.library.demo;

import com.library.repository.BookRepository;

public class BookService {

    private BookRepository bookRepository;

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void printBooks() {
        System.out.println("Printing books...");
        bookRepository.getBooks().forEach(System.out::println);
    }
}
