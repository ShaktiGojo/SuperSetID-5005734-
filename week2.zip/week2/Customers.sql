CREATE TABLE Customers (
    CustomerID NUMBER PRIMARY KEY,
    Name VARCHAR2(100),
    DOB DATE,
    Balance NUMBER,
    LastModified DATE
);
INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (1, 'John Doe', TO_DATE('1985-05-15', 'YYYY-MM-DD'), 1000, SYSDATE);

INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (2, 'Jane Smith', TO_DATE('1990-07-20', 'YYYY-MM-DD'), 1500, SYSDATE);

DECLARE
    CURSOR customer_cursor IS
        SELECT customer_id, age, loan_interest_rate
        FROM customers
        WHERE age > 60;

    v_customer_id customers.customer_id%TYPE;
    v_loan_interest_rate customers.loan_interest_rate%TYPE;
BEGIN
    FOR customer_record IN customer_cursor LOOP
        v_customer_id := customer_record.customer_id;
        v_loan_interest_rate := customer_record.loan_interest_rate;

        UPDATE loans
        SET interest_rate = v_loan_interest_rate * 0.99
        WHERE customer_id = v_customer_id;

        DBMS_OUTPUT.PUT_LINE('Applied 1% discount for customer ID ' || v_customer_id);
    END LOOP;
    
    COMMIT;
END;
/
DECLARE
    CURSOR customer_cursor IS
        SELECT customer_id, balance
        FROM customers;

    v_customer_id customers.customer_id%TYPE;
    v_balance customers.balance%TYPE;
BEGIN
    FOR customer_record IN customer_cursor LOOP
        v_customer_id := customer_record.customer_id;
        v_balance := customer_record.balance;

        IF v_balance > 10000 THEN
            UPDATE customers
            SET is_vip = TRUE
            WHERE customer_id = v_customer_id;

            DBMS_OUTPUT.PUT_LINE('Customer ID ' || v_customer_id || ' is now a VIP.');
        END IF;
    END LOOP;
    
    COMMIT;
END;
/
DECLARE
    CURSOR loan_cursor IS
        SELECT loan_id, customer_id, due_date
        FROM loans
        WHERE due_date BETWEEN SYSDATE AND SYSDATE + INTERVAL '30' DAY;

    v_loan_id loans.loan_id%TYPE;
    v_customer_id loans.customer_id%TYPE;
    v_due_date loans.due_date%TYPE;
BEGIN
    FOR loan_record IN loan_cursor LOOP
        v_loan_id := loan_record.loan_id;
        v_customer_id := loan_record.customer_id;
        v_due_date := loan_record.due_date;

        DBMS_OUTPUT.PUT_LINE('Reminder: Loan ID ' || v_loan_id || ' for customer ID ' || v_customer_id || ' is due on ' || v_due_date);
    END LOOP;
END;
/
