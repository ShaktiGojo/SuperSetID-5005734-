CREATE TABLE Loans (
    LoanID NUMBER PRIMARY KEY,
    CustomerID NUMBER,
    LoanAmount NUMBER,
    InterestRate NUMBER,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);
INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (1, 1, 5000, 5, SYSDATE, ADD_MONTHS(SYSDATE, 60));


CREATE OR REPLACE FUNCTION CalculateAge (
    p_date_of_birth IN DATE
) RETURN NUMBER AS
    v_age NUMBER;
BEGIN

    v_age := FLOOR(MONTHS_BETWEEN(SYSDATE, p_date_of_birth) / 12);

    RETURN v_age;
END CalculateAge;
/


CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment (
    p_loan_amount IN NUMBER,
    p_annual_interest_rate IN NUMBER,
    p_loan_duration_years IN NUMBER
) RETURN NUMBER AS
    v_monthly_installment NUMBER;
    v_monthly_interest_rate NUMBER;
    v_total_months NUMBER;
BEGIN

    v_monthly_interest_rate := p_annual_interest_rate / 12 / 100;


    v_total_months := p_loan_duration_years * 12;


    v_monthly_installment := (p_loan_amount * v_monthly_interest_rate) /
                            (1 - POWER(1 + v_monthly_interest_rate, -v_total_months));

    RETURN v_monthly_installment;
END CalculateMonthlyInstallment;
/


CREATE OR REPLACE FUNCTION HasSufficientBalance (
    p_account_id IN NUMBER,
    p_amount IN NUMBER
) RETURN BOOLEAN AS
    v_balance NUMBER;
BEGIN

    SELECT Balance INTO v_balance
    FROM Accounts
    WHERE AccountID = p_account_id;


    RETURN v_balance >= p_amount;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN FALSE; 
END HasSufficientBalance;
/
